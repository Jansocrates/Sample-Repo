package miniproject1;

import java.util.ArrayList;
import java.util.List;

public class ProjectImplementation {
	public static void main(String arg[]) {

		ArrayList<Subject> Subjectlist1 = new ArrayList<Subject>();

		Subject s1Math = new Subject(1, "Janani", 50);
		Subject s1Science = new Subject(2, "Janani", 70);
		Subject s1Computer = new Subject(3, "Janani", 80);

		Subjectlist1.add(s1Math);
		Subjectlist1.add(s1Science);
		Subjectlist1.add(s1Computer);

		ArrayList<Subject> Subjectlist2 = new ArrayList<Subject>();
		Subject s2Math = new Subject(1, "Priya", 30);
		Subject s2Science = new Subject(2, "Priya", 60);
		Subject s2Computer = new Subject(3, "Priya", 50);

		Subjectlist2.add(s2Math);
		Subjectlist2.add(s2Science);
		Subjectlist2.add(s2Computer);

		ArrayList<Subject> Subjectlist3 = new ArrayList<Subject>();
		Subject s3Math = new Subject(1, "Nila", 40);
		Subject s3Science = new Subject(2, "Nila", 70);
		Subject s3Computer = new Subject(3, "Nila", 55);

		Subjectlist3.add(s3Math);
		Subjectlist3.add(s3Science);
		Subjectlist3.add(s3Computer);

		ArrayList<Student> SD = new ArrayList<Student>();
		Student StudentS1 = new Student(701, "Janani", "10", Subjectlist1);
		Student StudentS2 = new Student(702, "priya", "10", Subjectlist2);
		Student StudentS3 = new Student(703, "Nila", "10", Subjectlist3);

		SD.add(StudentS1);
		SD.add(StudentS2);
		SD.add(StudentS3);

		ArrayList<Student> passedstudent = getpassedStudentList(SD);
		for (Student finalmarks : passedstudent)

		{
			System.out.println("name= " + finalmarks.getName() + ",standard= "+finalmarks.getStandard() +  ",total= "+finalmarks.getTotal()
					+",percentage= "+finalmarks.getPercentage());
		}

	}

	public static ArrayList<Student> getpassedStudentList(ArrayList<Student> studentList) {
		ArrayList<Student> FinalMarkList = new ArrayList<Student>();
		for (int i = 0; i < studentList.size(); i++) {
			Student StudentInfo = studentList.get(i);
			List<Subject> MarkList = StudentInfo.getSubjectList();

			int total = 0;
			boolean IsPassed = true;
			for (Subject SubjectMark : MarkList) 
			{
				int eachMark = SubjectMark.getMarks();
				if (eachMark < 50) {
					IsPassed = false;
					break;
				}
				total = total + eachMark;
			}
			if (IsPassed) {
				StudentInfo.setTotal(total);
				StudentInfo.setPercentage(total / (float) 3);
				FinalMarkList.add(StudentInfo);
			}

		}

		return FinalMarkList;
	}
}