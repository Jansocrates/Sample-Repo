package miniproject1;

import java.util.ArrayList;
import java.util.List;

public class Student {
	private int id;
	private String name;
	private String standard;
	private int total;
	private float percentage;
	private List<Subject> subjectList;

	public Student(int id, String name, String standard, List<Subject> sL) {
		this.setId(id);
		this.setName(name);
		this.setStandard(standard);
		this.setSubjectList(sL);

	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStandard() {
		return standard;
	}

	public void setStandard(String standard) {
		this.standard = standard;
	}

	public String toString() {
		return "Student[id=" + id + ",name=" + name + ",standard=" + standard + "]";
	}

	public float getPercentage() {
		return percentage;
	}

	public void setPercentage(float percentage) {
		this.percentage = percentage;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public List<Subject> getSubjectList() {
		return subjectList;
	}

	public void setSubjectList(List<Subject> subjectList) {
		this.subjectList = subjectList;
	}

}
